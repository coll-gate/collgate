# -*- coding: utf-8; -*-
#
# Copyright (c) 2014 INRA UMR1095 GDEC

"""
ohgr audit url entry point.
"""

from django.conf.urls import include, url

urlpatterns = [
]
