# -*- coding: utf-8; -*-
#
# Copyright (c) 2014 INRA UMR1095 GDEC

"""
ohgr permission module url entry point.
"""

from django.conf.urls import include, url

urlpatterns = [
]
