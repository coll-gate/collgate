# -*- coding: utf-8; -*-
#
# Copyright (c) 2014 INRA UMR1095 GDEC

"""
ohgr accession module url entry point.
"""

from django.conf.urls import include, url

urlpatterns = [
]
